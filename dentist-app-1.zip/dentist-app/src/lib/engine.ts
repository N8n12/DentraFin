// Earnings engine, ported from the prototype. Pure functions: no database, no UI.
export type Tier = { up: number | null; r: number };            // r = commission %
export type Practice = { id: string; name: string; uda: number; lab: number; tiers: Tier[] };
export type Treatment = { name: string; udas: number };
export type Entry = { id: string; created: string; d: string; t: string; p: string; c: number; l: number; ok: boolean; i?: string; n?: string; mod?: string };
export type Row = Entry & { u: number; uP: number; ch: number; com: number; ml: number; net: number; m: string };

export const n2 = (n: unknown) => +(+(n as number) || 0).toFixed(2);

/** Private commission is marginal (each slice earns its own rate) and bands reset every calendar month, per practice. */
export function calc(entries: Entry[], practices: Practice[], treatments: Treatment[]): Row[] {
  const udaOf = (name: string) => treatments.find(t => t.name === name)?.udas ?? 0;
  const pr = (id: string) => practices.find(x => x.id === id) ?? practices[0];
  const es = [...entries].sort((a, b) => (a.d < b.d ? -1 : a.d > b.d ? 1 : a.created < b.created ? -1 : a.created > b.created ? 1 : 0));
  const cum: Record<string, number> = {};
  return es.map(e => {
    const P = pr(e.p), u = udaOf(e.t), m = e.d.slice(0, 7), k = `${P.id}|${m}`, ch = +e.c || 0;
    let pos = cum[k] || 0, rem = ch, com = 0;
    if (ch > 0) for (const t of P.tiers) {
      const hi = t.up == null ? Infinity : t.up;
      if (rem > 0 && pos < hi) { const x = Math.min(rem, hi - pos); com += (x * t.r) / 100; pos += x; rem -= x; }
    }
    cum[k] = (cum[k] || 0) + ch;
    const uP = n2(e.ok ? u * P.uda : 0), ml = n2(((+e.l || 0) * P.lab) / 100), c2 = n2(com);
    return { ...e, p: P.id, u, uP, ch, com: c2, ml, net: n2(uP + c2 - ml), m };
  });
}

export type Period = { from: string; to: string; mk: string; udas: number; uP: number; ch: number; com: number; lab: number; net: number; n: number; pend: number; payDate: string };

/** NHS UDA periods run between processing cut-off dates; private commission and non-UDA lab fees use the calendar month of the cut-off. */
export function periods(rows: Row[], cutoffs: string[], payDay: number): Period[] {
  const c = [...cutoffs].sort(), P: { from: string; to: string; mk: string }[] = [];
  for (let i = 1; i < c.length; i++) P.push({ from: c[i - 1], to: c[i], mk: c[i].slice(0, 7) });
  const last = c[c.length - 1], open = rows.filter(r => r.d > last);
  if (open.length) P.push({ from: last, to: '9999', mk: open[open.length - 1].m });
  const sum = (a: Row[], k: 'u' | 'uP' | 'ch' | 'com' | 'ml') => a.reduce((s, r) => s + r[k], 0);
  return P.map(p => {
    const w = rows.filter(r => r.d > p.from && r.d <= p.to && r.u > 0), pv = rows.filter(r => r.m === p.mk && r.ch > 0), ol = rows.filter(r => r.m === p.mk && r.u === 0);
    const lab = sum(w, 'ml') + sum(ol, 'ml'), uP = sum(w, 'uP'), com = sum(pv, 'com');
    const [y, m] = p.mk.split('-').map(Number), d = new Date(Date.UTC(y, m, Math.min(payDay, 28)));
    while ([0, 6].includes(d.getUTCDay())) d.setUTCDate(d.getUTCDate() - 1);   // pay day of next month, moved back to a weekday
    return { ...p, udas: sum(w.filter(r => r.ok), 'u'), uP, ch: sum(pv, 'ch'), com, lab, net: n2(uP + com - lab), n: w.length + pv.length, pend: w.filter(r => !r.ok).length, payDate: d.toISOString().slice(0, 10) };
  }).filter(p => p.n).reverse();
}
