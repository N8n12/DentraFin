export const gbp = (n: number) => (n < 0 ? '-' : '') + '£' + Math.abs(n).toLocaleString('en-GB', { minimumFractionDigits: 2, maximumFractionDigits: 2 });
export const fd = (d: string) => new Date(d + 'T00:00').toLocaleDateString('en-GB', { weekday: 'short', day: 'numeric', month: 'short', year: 'numeric' });
export const fm = (k: string) => new Date(k + '-01T00:00').toLocaleDateString('en-GB', { month: 'long', year: 'numeric' });
export const today = () => { const d = new Date(); return new Date(+d - d.getTimezoneOffset() * 6e4).toISOString().slice(0, 10); };
export const fds = (d: string) => new Date(d + 'T00:00').toLocaleDateString('en-GB', { weekday: 'short', day: 'numeric', month: 'short' });
export const tsf = (t: string) => new Date(t).toLocaleString('en-GB', { day: 'numeric', month: 'short', year: 'numeric', hour: '2-digit', minute: '2-digit' });
export const wkStart = (d: string) => { const x = new Date(d + 'T00:00Z'); x.setUTCDate(x.getUTCDate() - ((x.getUTCDay() + 6) % 7)); return x.toISOString().slice(0, 10); };
