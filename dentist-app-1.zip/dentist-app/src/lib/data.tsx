'use client';
import { createContext, useCallback, useContext, useEffect, useState, ReactNode } from 'react';
import { sb } from './supabase';
import { Entry, Practice, Treatment } from './engine';

type Base = { practices: Practice[]; treatments: Treatment[]; entries: Entry[]; cutoffs: string[]; payDay: number; taxPct: number; pay: Record<string, number>; theme: string; accent: string; accent2: string };
type D = Base & { filter: string; setFilter: (f: string) => void; reload: () => Promise<void>; saveSettings: (patch: Record<string, string>) => Promise<void> };
const Ctx = createContext<D | null>(null);
export const useData = () => useContext(Ctx);   // null while loading

export function DataProvider({ children }: { children: ReactNode }) {
  const [d, setD] = useState<Base | null>(null);
  const [filter, setFilter] = useState('all');
  const reload = useCallback(async () => {
    const [p, t, e, s, a] = await Promise.all([
      sb.from('practices').select('*').order('created_at'), sb.from('treatments').select('*').order('sort'),
      sb.from('entries').select('*').order('entry_date', { ascending: false }).limit(1000),
      sb.from('settings').select('*').maybeSingle(), sb.from('actual_pay').select('*')]);
    /* eslint-disable @typescript-eslint/no-explicit-any */
    setD({
      practices: (p.data ?? []).map((x: any) => ({ id: x.id, name: x.name, uda: +x.uda_rate, lab: +x.lab_share, tiers: x.tiers })),
      treatments: (t.data ?? []).map((x: any) => ({ name: x.name, udas: +x.udas })),
      entries: (e.data ?? []).map((x: any) => ({ id: x.id, created: x.created_at, d: x.entry_date, t: x.treatment, p: x.practice_id, c: +x.private_charge, l: +x.lab_fee, ok: x.submitted, i: x.initials ?? '', n: x.note ?? '', mod: x.updated_at })),
      cutoffs: s.data?.cutoffs ?? [], payDay: s.data?.pay_day ?? 15, taxPct: +(s.data?.tax_pct ?? 35),
      theme: s.data?.theme ?? 'light', accent: s.data?.accent ?? '#156082', accent2: s.data?.accent2 ?? '#4EA72E',
      pay: Object.fromEntries((a.data ?? []).map((x: any) => [x.month, +x.amount])),
    });
  }, []);
  const saveSettings = useCallback(async (patch: Record<string, string>) => {
    const { data: { user } } = await sb.auth.getUser();
    await sb.from('settings').update(patch).eq('user_id', user!.id); await reload();
  }, [reload]);
  useEffect(() => { reload(); }, [reload]);
  return <Ctx.Provider value={d && { ...d, filter, setFilter, reload, saveSettings }}>{children}</Ctx.Provider>;
}
