import { describe, it, expect } from 'vitest';
import { calc, periods, Practice, Entry } from './engine';

const tiers = [{ up: 1000, r: 40 }, { up: 2000, r: 50 }, { up: null, r: 60 }];
const A: Practice = { id: 'A', name: 'A', uda: 12, lab: 50, tiers };
const B: Practice = { id: 'B', name: 'B', uda: 15, lab: 40, tiers: [{ up: null, r: 30 }] };
const tx = [{ name: 'Crown', udas: 12 }, { name: 'Private', udas: 0 }];
let n = 0;
const e = (d: string, t: string, p: string, c = 0, l = 0, ok = true): Entry => ({ id: 'e' + n, created: String(n++).padStart(4, '0'), d, t, p, c, l, ok });

describe('private commission', () => {
  it('is marginal across bands and accumulates within a month', () => {
    const r = calc([e('2026-09-01', 'Private', 'A', 900), e('2026-09-02', 'Private', 'A', 300), e('2026-09-03', 'Private', 'A', 2000)], [A], tx);
    expect(r.map(x => x.com)).toEqual([360, 140, 1120]);   // 900@40 | 100@40+200@50 | 800@50+1200@60
  });
  it('resets on the first of the next month', () => {
    const r = calc([e('2026-09-30', 'Private', 'A', 1500), e('2026-10-01', 'Private', 'A', 500)], [A], tx);
    expect(r[1].com).toBe(200);
  });
  it('tracks each practice separately', () => {
    const r = calc([e('2026-09-01', 'Private', 'A', 900), e('2026-09-01', 'Private', 'B', 1000)], [A, B], tx);
    expect(r[1].com).toBe(300);
  });
});
describe('UDA income and lab fees', () => {
  it('pays UDAs at the practice rate, and nothing while pending', () => {
    const r = calc([e('2026-09-01', 'Crown', 'A'), e('2026-09-01', 'Crown', 'A', 0, 0, false)], [A], tx);
    expect([r[0].uP, r[1].uP]).toEqual([144, 0]);
  });
  it('takes the practice lab share off net', () => {
    const [r] = calc([e('2026-09-01', 'Private', 'A', 500, 100)], [A], tx);
    expect([r.ml, r.com, r.net]).toEqual([50, 200, 150]);
  });
});
describe('pay periods', () => {
  it('groups UDAs by cut-off and dates pay on a weekday', () => {
    const rows = calc([e('2026-09-10', 'Crown', 'A'), e('2026-09-25', 'Crown', 'A')], [A], tx);
    const p = periods(rows, ['2026-08-18', '2026-09-22', '2026-10-20'], 15);
    expect(p.map(x => [x.mk, x.udas])).toEqual([['2026-10', 12], ['2026-09', 12]]);
    expect(p[1].payDate).toBe('2026-10-15');
  });
});
