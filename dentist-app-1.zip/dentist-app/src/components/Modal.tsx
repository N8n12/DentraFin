'use client';
import { useEffect, ReactNode } from 'react';
export default function Modal({ title, onClose, children }: { title: string; onClose: () => void; children: ReactNode }) {
  useEffect(() => {
    const k = (e: KeyboardEvent) => e.key === 'Escape' && onClose();
    document.addEventListener('keydown', k); document.body.style.overflow = 'hidden';
    return () => { document.removeEventListener('keydown', k); document.body.style.overflow = ''; };
  }, [onClose]);
  return (
    <div className="mdl" onClick={e => e.target === e.currentTarget && onClose()}>
      <div className="sheet"><div className="li" style={{ border: 0, paddingTop: 0 }}><b style={{ fontSize: 18 }}>{title}</b><button className="d" onClick={onClose}>✕</button></div>{children}</div>
    </div>
  );
}
