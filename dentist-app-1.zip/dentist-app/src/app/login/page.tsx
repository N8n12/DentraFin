'use client';
import { useState } from 'react';
import { useRouter } from 'next/navigation';
import { sb } from '@/lib/supabase';

export default function Login() {
  const r = useRouter();
  const [email, setEmail] = useState(''), [pw, setPw] = useState(''), [signup, setSignup] = useState(false), [msg, setMsg] = useState('');
  const oauth = (provider: 'google' | 'apple') => sb.auth.signInWithOAuth({ provider, options: { redirectTo: location.origin + '/add' } });
  async function submit(e: React.FormEvent) {
    e.preventDefault(); setMsg('');
    if (signup) {
      const { data, error } = await sb.auth.signUp({ email, password: pw });
      if (error) return setMsg(error.message);
      if (!data.session) return setMsg('Check your email to confirm your account, then sign in.');
    } else {
      const { error } = await sb.auth.signInWithPassword({ email, password: pw });
      if (error) return setMsg(error.message);
    }
    r.replace('/add');
  }
  return (
    <div className="login"><div className="card">
      <h1>🦷 Earnings tracker</h1>
      <button className="big" onClick={() => oauth('google')}>Continue with Google</button>
      <button className="big g" onClick={() => oauth('apple')}>Continue with Apple</button>
      <p className="m" style={{ textAlign: 'center' }}>or use email</p>
      <form onSubmit={submit}>
        <label>Email</label><input type="email" required value={email} onChange={e => setEmail(e.target.value)} />
        <label>Password</label><input type="password" required minLength={8} value={pw} onChange={e => setPw(e.target.value)} />
        <button className="big" type="submit">{signup ? 'Create account' : 'Sign in'}</button>
      </form>
      <p className="m" style={{ marginTop: 12 }}>{msg}</p>
      <button className="d" onClick={() => setSignup(!signup)}>{signup ? 'I already have an account' : 'Create an account'}</button>
    </div></div>
  );
}
