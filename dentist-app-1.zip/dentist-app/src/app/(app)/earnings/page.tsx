'use client';
import { useState } from 'react';
import { sb } from '@/lib/supabase';
import { useData } from '@/lib/data';
import { calc, periods, n2, Row } from '@/lib/engine';
import { gbp, fd, fm, fds, wkStart } from '@/lib/format';
import Modal from '@/components/Modal';

type L = { k: 'uda' | 'pv'; t: 'm' | 'w'; key: string };
type Wk = { w: string; udas: number; uP: number; ml: number; ch: number; com: number; net: number; days: Set<string> };

export default function Earnings() {
  const d = useData(), [sub, setSub] = useState<'m' | 'w'>('m'), [lst, setLst] = useState<L | null>(null);
  if (!d) return <p className="m">Loading…</p>;
  const rows = calc(d.entries, d.practices, d.treatments).filter(r => d.filter === 'all' || r.p === d.filter), P = periods(rows, d.cutoffs, d.payDay);
  async function setPay(month: string, v: string) { if (v !== '') { await sb.from('actual_pay').upsert({ month, amount: n2(v) }); await d!.reload(); } }

  const W: Record<string, Wk> = {}, D: Record<string, number> = {};
  rows.forEach(r => {
    const w = wkStart(r.d), b = (W[w] = W[w] || { w, udas: 0, uP: 0, ml: 0, ch: 0, com: 0, net: 0, days: new Set<string>() });
    b.udas += r.ok ? r.u : 0; b.uP += r.uP; b.ml += r.ml; b.ch += r.ch; b.com += r.com; b.net += r.net; b.days.add(r.d); D[r.d] = (D[r.d] || 0) + r.net;
  });
  const wks = Object.values(W).sort((a, b) => (a.w < b.w ? 1 : -1)), rk = [...wks].sort((a, b) => b.net - a.net).map(x => x.w);
  const best = Object.entries(D).sort((a, b) => b[1] - a[1]).slice(0, 5), avg = Object.keys(D).length ? Object.values(D).reduce((s, v) => s + v, 0) / Object.keys(D).length : 0;

  let sel: Row[] = [], title = '';
  if (lst) {
    const uda = lst.k === 'uda';
    if (lst.t === 'm') { const p = P.find(x => x.mk === lst.key); sel = p ? rows.filter(r => (uda ? r.d > p.from && r.d <= p.to && r.u > 0 : r.m === p.mk && r.ch > 0)) : []; title = fm(lst.key); }
    else { sel = rows.filter(r => wkStart(r.d) === lst.key && (uda ? r.u > 0 : r.ch > 0)); title = 'Week of ' + fd(lst.key).replace(/^\w+, /, ''); }
    sel = [...sel].sort((a, b) => (a.d < b.d ? -1 : 1));
  }
  const open = (k: L['k'], t: L['t'], key: string) => () => setLst({ k, t, key });
  const name = (id: string) => d.practices.find(p => p.id === id)?.name;

  return (
    <>
      <div className="seg"><button className={sub === 'm' ? 'on' : ''} onClick={() => setSub('m')}>Pay periods</button><button className={sub === 'w' ? 'on' : ''} onClick={() => setSub('w')}>Weeks &amp; best days</button></div>

      {sub === 'm' && <>
        {!P.length && <div className="card m">Nothing to show yet. Add entries first.</div>}
        {P.map((p, i) => {
          const sv = d.pay[p.mk], tax = ((sv ?? p.net) * d.taxPct) / 100, df = sv == null ? null : n2(sv - p.net);
          return (
            <details className="card per" key={p.mk} open={i === 0}>
              <summary><div>{fm(p.mk)}<div className="m">Paid ~{fd(p.payDate)}</div></div><span className="nt">{gbp(p.net)}</span></summary>
              <div className="kpis">
                <div className="k g tp" onClick={open('uda', 'm', p.mk)}><b>{p.udas}</b><span>UDAs{p.pend ? ` (${p.pend} pending)` : ''}</span></div>
                <div className="k g tp" onClick={open('uda', 'm', p.mk)}><b>{gbp(p.uP)}</b><span>UDA income</span></div>
                <div className="k g tp" onClick={open('pv', 'm', p.mk)}><b>{gbp(p.ch)}</b><span>Private billed</span></div>
                <div className="k g tp" onClick={open('pv', 'm', p.mk)}><b>{gbp(p.com)}</b><span>Commission</span></div>
                <div className="k l"><b>−{gbp(p.lab)}</b><span>Lab fees (your share)</span></div>
                <div className="k l"><b>{gbp(tax)}</b><span>Tax set-aside: {d.taxPct}% of {sv != null ? 'actual pay' : 'expected net'}</span></div>
              </div>
              <div className="m" style={{ marginTop: 10 }}>Tax set-aside uses your expected net until you enter the actual pay below, then switches to that.</div>
              <div className="row" style={{ alignItems: 'end' }}>
                <div><label>Actual pay received £</label><input type="number" step="0.01" defaultValue={sv ?? ''} onBlur={e => setPay(p.mk, e.target.value)} /></div>
                <div className="k"><b style={{ color: df != null && df < 0 ? 'var(--bad)' : undefined }}>{df == null ? '–' : (df >= 0 ? '+' : '') + gbp(df)}</b><span>Difference vs estimate</span></div>
              </div>
            </details>);
        })}</>}

      {sub === 'w' && (wks.length ? <>
        <div className="card"><b>Best days</b><div className="m">Average day {gbp(avg)} across {Object.keys(D).length} days</div>
          {best.map(([day, v], i) => <div className="li" key={day}><span>{i + 1}. {fd(day)}</span><b>{gbp(v)}</b></div>)}</div>
        <h2>Weekly totals (Mon–Sun)</h2>
        <div className="card" style={{ padding: '4px 14px' }}>
          {wks.map(x => (
            <details className="wk" key={x.w}>
              <summary><div>Week of {fd(x.w).replace(/^\w+, /, '')}<div className="m" style={{ fontWeight: 400 }}>{x.days.size} days worked</div></div><b>{gbp(x.net)}</b></summary>
              <div className="kpis">
                <div className="k g tp" onClick={open('uda', 'w', x.w)}><b>{n2(x.udas)}</b><span>Total UDAs</span></div>
                <div className="k g tp" onClick={open('uda', 'w', x.w)}><b>{gbp(x.uP)}</b><span>UDA income</span></div>
                <div className="k g tp" onClick={open('pv', 'w', x.w)}><b>{gbp(x.ch)}</b><span>Private billed</span></div>
                <div className="k g tp" onClick={open('pv', 'w', x.w)}><b>{gbp(x.com)}</b><span>Private commission</span></div>
                <div className="k g"><b>{gbp(x.uP + x.com)}</b><span>Gross (before lab fees)</span></div>
                <div className="k l"><b>−{gbp(x.ml)}</b><span>Lab fees (your share)</span></div>
                <div className="k n"><b>{gbp(x.net)}</b><span>Net · ranked {rk.indexOf(x.w) + 1} of {wks.length} weeks</span></div>
              </div>
            </details>))}
        </div></> : <div className="card m">No entries yet.</div>)}

      {lst && (
        <Modal title={lst.k === 'uda' ? 'UDA activity' : 'Private activity'} onClose={() => setLst(null)}>
          <div className="m">{title} · {sel.length} entries</div>
          <div className="kpis">
            <div className="k g"><b>{lst.k === 'uda' ? n2(sel.reduce((s, r) => s + (r.ok ? r.u : 0), 0)) + ' UDAs' : gbp(sel.reduce((s, r) => s + r.ch, 0)) + ' billed'}</b><span>Total</span></div>
            <div className="k g"><b>{gbp(sel.reduce((s, r) => s + (lst.k === 'uda' ? r.uP : r.com), 0))}</b><span>{lst.k === 'uda' ? 'UDA income' : 'Your commission'}</span></div>
          </div>
          {sel.map(r => (
            <div className="li" key={r.id}>
              <div>{r.i && <b>{r.i} · </b>}{r.t}{!r.ok && <span className="tag">pending</span>}{d.practices.length > 1 && <span className="tag pr">{name(r.p)}</span>}<div className="m">{fds(r.d)}{r.n ? ' · ' + r.n : ''}</div></div>
              <div style={{ textAlign: 'right' }}><b>{lst.k === 'uda' ? n2(r.u) + ' UDAs' : gbp(r.ch)}</b><div className="m">{lst.k === 'uda' ? gbp(r.uP) : gbp(r.com)}</div></div>
            </div>))}
          {!sel.length && <div className="m">No activity in this period.</div>}
        </Modal>)}
    </>
  );
}
