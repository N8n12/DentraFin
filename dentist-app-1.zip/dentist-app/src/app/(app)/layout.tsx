'use client';
import Link from 'next/link';
import { usePathname, useRouter } from 'next/navigation';
import { useEffect, useState } from 'react';
import { sb } from '@/lib/supabase';
import { DataProvider, useData } from '@/lib/data';

const NAV = [['/add', '＋', 'Add'], ['/log', '☰', 'Log'], ['/earnings', '£', 'Earnings'], ['/referrals', '⇄', 'Referrals'], ['/settings', '⚙', 'Settings']];

function Theme() {
  const d = useData();
  useEffect(() => {
    if (!d) return;
    const r = document.documentElement, dk = d.theme === 'dark' || (d.theme === 'auto' && matchMedia('(prefers-color-scheme:dark)').matches);
    r.setAttribute('data-dk', dk ? '1' : '0'); r.style.setProperty('--acc', d.accent); r.style.setProperty('--sec', d.accent2); r.style.colorScheme = dk ? 'dark' : 'light';
  }, [d]);
  return null;
}

function Header() {
  const d = useData();
  return (
    <header><b>🦷 Earnings</b>
      {d && d.practices.length > 1 && (
        <select value={d.filter} onChange={e => d.setFilter(e.target.value)}>
          <option value="all">All practices</option>{d.practices.map(p => <option key={p.id} value={p.id}>{p.name}</option>)}
        </select>)}
    </header>
  );
}

export default function AppLayout({ children }: { children: React.ReactNode }) {
  const r = useRouter(), path = usePathname(), [ok, setOk] = useState(false);
  useEffect(() => { sb.auth.getSession().then(({ data }) => (data.session ? setOk(true) : r.replace('/login'))); }, [r]);
  if (!ok) return null;
  return (
    <DataProvider>
      <Theme /><Header />
      <nav>{NAV.map(([h, i, l]) => <Link key={h} href={h} className={path === h ? 'on' : ''}><i>{i}</i>{l}</Link>)}</nav>
      <main>{children}</main>
    </DataProvider>
  );
}
