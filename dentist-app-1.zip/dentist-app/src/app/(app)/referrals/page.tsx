'use client';
import { useCallback, useEffect, useState } from 'react';
import { sb } from '@/lib/supabase';
import { fd, today } from '@/lib/format';

type R = { id: string; ref_date: string; patient_ref: string | null; referred_to: string | null; reason: string | null; sent_via: string | null; sent: boolean; made: boolean };

export default function Referrals() {
  const [rs, setRs] = useState<R[]>([]), [f, setF] = useState({ d: today(), n: '', t: '', r: '', x: '' });
  const load = useCallback(async () => { const { data } = await sb.from('referrals').select('*').order('ref_date', { ascending: false }); setRs((data ?? []) as R[]); }, []);
  useEffect(() => { load(); }, [load]);
  async function add() { await sb.from('referrals').insert({ ref_date: f.d, patient_ref: f.n, referred_to: f.t, reason: f.r, sent_via: f.x }); setF({ ...f, n: '', t: '', r: '', x: '' }); load(); }
  async function tg(r: R, k: 'sent' | 'made') { await sb.from('referrals').update({ [k]: !r[k] }).eq('id', r.id); load(); }
  async function del(id: string) { if (confirm('Delete this referral?')) { await sb.from('referrals').delete().eq('id', id); load(); } }
  const set = (k: string, v: string) => setF({ ...f, [k]: v });
  return (
    <>
      <div className="card">
        <label>Date</label><input type="date" value={f.d} onChange={e => set('d', e.target.value)} />
        <label>Patient reference (initials or ID, not a full name)</label><input value={f.n} onChange={e => set('n', e.target.value)} />
        <div className="row"><div><label>Referred to</label><input value={f.t} onChange={e => set('t', e.target.value)} /></div><div><label>Reason</label><input value={f.r} onChange={e => set('r', e.target.value)} /></div></div>
        <label>Sent to / how</label><input value={f.x} onChange={e => set('x', e.target.value)} />
        <button className="big" onClick={add}>Add referral</button>
      </div>
      {rs.length > 0 && <div className="m" style={{ marginBottom: 8 }}>{rs.filter(r => r.sent && !r.made).length} sent, awaiting confirmation</div>}
      {rs.map(r => (
        <div className="card" key={r.id}>
          <div className="li" style={{ border: 0, padding: 0 }}><b>{r.patient_ref || '(no ref)'}</b><span className="m">{fd(r.ref_date)}</span></div>
          <div className="m">{[r.referred_to && 'To: ' + r.referred_to, r.reason && 'Reason: ' + r.reason, r.sent_via && 'Via: ' + r.sent_via].filter(Boolean).join(' · ')}</div>
          <div className="row" style={{ marginTop: 8 }}>
            <button className={r.sent ? '' : 'g'} onClick={() => tg(r, 'sent')}>{r.sent ? '✓ ' : ''}Sent</button>
            <button className={r.made ? '' : 'g'} onClick={() => tg(r, 'made')}>{r.made ? '✓ ' : ''}Made</button>
            <button className="d" style={{ flex: 0 }} onClick={() => del(r.id)}>✕</button>
          </div>
        </div>))}
    </>
  );
}
