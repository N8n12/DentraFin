'use client';
import { useState } from 'react';
import { sb } from '@/lib/supabase';
import { useData } from '@/lib/data';
import { calc, n2, Row } from '@/lib/engine';
import { gbp, fd, tsf } from '@/lib/format';
import Modal from '@/components/Modal';

function EditEntry({ e, onClose }: { e: Row; onClose: () => void }) {
  const d = useData()!;
  const [f, setF] = useState({ d: e.d, p: e.p, t: e.t, i: e.i ?? '', c: e.c ? String(e.c) : '', l: e.l ? String(e.l) : '', n: e.n ?? '', ok: e.ok });
  const set = (k: string, v: string | boolean) => setF({ ...f, [k]: v });
  async function save() {
    await sb.from('entries').update({ entry_date: f.d, practice_id: f.p, treatment: f.t, initials: f.i.trim().toUpperCase() || null, note: f.n || null, private_charge: n2(f.c), lab_fee: n2(f.l), submitted: f.ok }).eq('id', e.id);
    await d.reload(); onClose();
  }
  async function del() { if (confirm('Delete this entry?')) { await sb.from('entries').delete().eq('id', e.id); await d.reload(); onClose(); } }
  const edited = e.mod && Math.abs(+new Date(e.mod) - +new Date(e.created)) > 2000;
  return (
    <Modal title="Edit entry" onClose={onClose}>
      <div className="row"><div><label>Date</label><input type="date" value={f.d} onChange={x => set('d', x.target.value)} /></div>
        {d.practices.length > 1 && <div><label>Practice</label><select value={f.p} onChange={x => set('p', x.target.value)}>{d.practices.map(p => <option key={p.id} value={p.id}>{p.name}</option>)}</select></div>}</div>
      <label>Treatment</label><select value={f.t} onChange={x => set('t', x.target.value)}>{d.treatments.map(t => <option key={t.name}>{t.name}</option>)}</select>
      <div className="row"><div><label>Private charge £</label><input type="number" step="0.01" value={f.c} onChange={x => set('c', x.target.value)} /></div><div><label>Total lab fee £</label><input type="number" step="0.01" value={f.l} onChange={x => set('l', x.target.value)} /></div></div>
      <label>Patient initials</label><input maxLength={6} value={f.i} onChange={x => set('i', x.target.value)} style={{ textTransform: 'uppercase' }} />
      <label>Note</label><input value={f.n} onChange={x => set('n', x.target.value)} />
      <label className="chk"><input type="checkbox" checked={f.ok} onChange={x => set('ok', x.target.checked)} /> Submitted to NHS</label>
      <div className="m" style={{ marginTop: 10 }}>Added: {tsf(e.created)}<br />Last modified: {edited ? tsf(e.mod!) : 'never edited'}</div>
      <div className="row" style={{ marginTop: 10 }}><button onClick={save}>Save changes</button><button className="g" onClick={onClose}>Cancel</button></div>
      <button className="d" onClick={del}>Delete entry</button>
    </Modal>
  );
}

export default function Log() {
  const d = useData(), [lim, setLim] = useState(14), [ed, setEd] = useState<Row | null>(null);
  if (!d) return <p className="m">Loading…</p>;
  const rows = calc(d.entries, d.practices, d.treatments).filter(r => d.filter === 'all' || r.p === d.filter), g: Record<string, Row[]> = {};
  rows.forEach(r => (g[r.d] = g[r.d] || []).push(r));
  const all = Object.keys(g).sort().reverse(), days = all.slice(0, lim), name = (id: string) => d.practices.find(p => p.id === id)?.name;
  async function del(id: string) { if (confirm('Delete this entry?')) { await sb.from('entries').delete().eq('id', id); await d!.reload(); } }
  return (
    <>
      {!days.length && <div className="card m">No entries yet. Add one on the Add tab.</div>}
      {days.map(day => (
        <div className="card" key={day}>
          <div className="li"><b>{fd(day)}</b><b>{gbp(g[day].reduce((s, r) => s + r.net, 0))}</b></div>
          {g[day].map(r => (
            <div className="li tap" key={r.id} onClick={() => setEd(r)}>
              <div>{r.i && <b>{r.i} · </b>}{r.t}{!r.ok && <span className="tag">pending</span>}{d.practices.length > 1 && <span className="tag pr">{name(r.p)}</span>}
                <div className="m">{r.u ? r.u + ' UDAs' : ''}{r.ch ? ` private ${gbp(r.ch)} → ${gbp(r.com)}` : ''}{r.n ? ' · ' + r.n : ''}</div></div>
              <div style={{ whiteSpace: 'nowrap' }}>{gbp(r.net)} <span className="m">›</span> <button className="d" onClick={e => { e.stopPropagation(); del(r.id); }}>✕</button></div>
            </div>))}
        </div>))}
      {all.length > days.length && <button className="g big" onClick={() => setLim(lim + 14)}>Show more days ({all.length - days.length} older)</button>}
      {ed && <EditEntry e={ed} onClose={() => setEd(null)} />}
    </>
  );
}
