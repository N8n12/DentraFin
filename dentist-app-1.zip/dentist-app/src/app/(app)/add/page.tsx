'use client';
import { useRef, useState } from 'react';
import { sb } from '@/lib/supabase';
import { useData } from '@/lib/data';
import { calc, n2 } from '@/lib/engine';
import { gbp, fd, today } from '@/lib/format';

export default function Add() {
  const d = useData();
  const [mode, setMode] = useState<'n' | 'p'>('n'), [date, setDate] = useState(today()), [prac, setPrac] = useState(''),
    [tx, setTx] = useState(''), [ini, setIni] = useState(''), [ch, setCh] = useState(''), [lab, setLab] = useState(''),
    [note, setNote] = useState(''), [ok, setOk] = useState(true), [msg, setMsg] = useState('');
  const car = useRef<HTMLDivElement>(null);
  if (!d) return <p className="m">Loading…</p>;
  const nhs = d.treatments.filter(t => t.udas > 0), p = prac || d.practices[0]?.id, t = mode === 'p' ? 'Private' : tx || nhs[0]?.name;
  const rows = calc(d.entries, d.practices, d.treatments), day = rows.filter(r => r.d === date), sum = (k: 'net' | 'uP' | 'com' | 'ml') => day.reduce((s, r) => s + r[k], 0);
  const tmp = { id: 'tmp', created: '~', d: date, t, p, c: n2(ch), l: n2(lab), ok: true };
  const pv = calc([...d.entries, tmp], d.practices, d.treatments).find(r => r.id === 'tmp');
  async function add() {
    const { error } = await sb.from('entries').insert({ practice_id: p, entry_date: date, treatment: t, initials: ini.trim().toUpperCase() || null, note: note || null, private_charge: n2(ch), lab_fee: n2(lab), submitted: ok });
    if (error) return setMsg(error.message);
    setIni(''); setCh(''); setLab(''); setNote(''); setMsg('Added ✓'); await d!.reload(); setTimeout(() => setMsg(''), 1800);
  }
  const labIn = <><label>Total lab fee £</label><input type="number" inputMode="decimal" step="0.01" value={lab} onChange={e => setLab(e.target.value)} /></>;
  return (
    <div className="two">
      <div className="hero"><div className="m2">{fd(date)}</div><div className="hn">{gbp(sum('net'))}</div><div className="m2">Net for the day · {day.length} entries</div>
        <div className="mini"><span>UDA {gbp(sum('uP'))}</span><span>Private {gbp(sum('com'))}</span><span>Lab −{gbp(sum('ml'))}</span></div></div>
      <div className="card">
        <div className={'sw2 ' + (mode === 'p' ? 'p' : '')} onClick={() => setMode(mode === 'p' ? 'n' : 'p')}><i /><span className={mode === 'n' ? 'on' : ''}>NHS</span><span className={mode === 'p' ? 'on' : ''}>Private</span></div>
        {d.practices.length > 1 && <><label>Practice</label><select value={p} onChange={e => setPrac(e.target.value)}>{d.practices.map(x => <option key={x.id} value={x.id}>{x.name}</option>)}</select></>}
        <label>Date</label><input type="date" value={date} onChange={e => setDate(e.target.value)} />
        <label>Patient initials</label><input maxLength={6} placeholder="e.g. AB" value={ini} onChange={e => setIni(e.target.value)} style={{ textTransform: 'uppercase' }} />
        {mode === 'n'
          ? <><label>Treatment (UDAs)</label><div className="car"><button className="g cb" onClick={() => car.current?.scrollBy({ left: -car.current.clientWidth * 0.8, behavior: 'smooth' })}>‹</button>
            <div className="chips car2" ref={car}>{nhs.map(x => <button key={x.name} className={'chip ' + (x.name === t ? 'on' : '')} onClick={() => setTx(x.name)}>{x.name} <small>{x.udas}</small></button>)}</div>
            <button className="g cb" onClick={() => car.current?.scrollBy({ left: car.current.clientWidth * 0.8, behavior: 'smooth' })}>›</button></div>{labIn}</>
          : <div className="row"><div><label>Private charge £</label><input type="number" inputMode="decimal" step="0.01" value={ch} onChange={e => setCh(e.target.value)} /></div><div>{labIn}</div></div>}
        <details className="more"><summary>More options</summary><label>Note</label><input value={note} onChange={e => setNote(e.target.value)} />
          <label className="chk"><input type="checkbox" checked={ok} onChange={e => setOk(e.target.checked)} /> Submitted to NHS (untick if pending)</label></details>
        <div className="pv">{pv && <>UDAs {pv.u} · commission <b>{gbp(pv.com)}</b> · lab share <b>−{gbp(pv.ml)}</b> → net <b>{gbp(pv.net)}</b></>}</div>
        <button className="big" onClick={add}>Add entry</button><div className="ok">{msg}</div>
      </div>
    </div>
  );
}
