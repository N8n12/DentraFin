'use client';
import { useState } from 'react';
import { useRouter } from 'next/navigation';
import { sb } from '@/lib/supabase';
import { useData } from '@/lib/data';
import { Practice, n2 } from '@/lib/engine';

function PracticeForm({ p, reload, can }: { p: Practice; reload: () => Promise<void>; can: boolean }) {
  const [f, setF] = useState(p), [msg, setMsg] = useState('');
  const tier = (i: number, k: 'up' | 'r', v: string) => setF({ ...f, tiers: f.tiers.map((t, j) => (j === i ? { ...t, [k]: v === '' ? null : +v } : t)) });
  async function save() {
    const { error } = await sb.from('practices').update({ name: f.name, uda_rate: n2(f.uda), lab_share: n2(f.lab), tiers: f.tiers }).eq('id', p.id);
    setMsg(error ? error.message : 'Saved ✓'); await reload();
  }
  async function del() { if (confirm('Delete this practice? Its entries keep their data but lose the practice link.')) { await sb.from('practices').delete().eq('id', p.id); await reload(); } }
  return (
    <div className="card"><b>{p.name}</b>
      <label>Name</label><input value={f.name} onChange={e => setF({ ...f, name: e.target.value })} />
      <div className="row"><div><label>UDA rate £</label><input type="number" step="0.01" value={f.uda} onChange={e => setF({ ...f, uda: +e.target.value })} /></div>
        <div><label>Your lab fee share %</label><input type="number" value={f.lab} onChange={e => setF({ ...f, lab: +e.target.value })} /></div></div>
      <label>Private commission bands (each slice earns its own rate, resets monthly). Left: up to £ (blank = no limit). Right: %.</label>
      {f.tiers.map((t, i) => <div className="sm" key={i}><input type="number" step="0.01" placeholder="up to £" value={t.up ?? ''} onChange={e => tier(i, 'up', e.target.value)} /><input type="number" style={{ maxWidth: 90 }} value={t.r} onChange={e => tier(i, 'r', e.target.value)} />
        <button className="d" onClick={() => setF({ ...f, tiers: f.tiers.filter((_, j) => j !== i) })}>✕</button></div>)}
      <button className="g" onClick={() => setF({ ...f, tiers: [...f.tiers, { up: null, r: 50 }] })}>+ Add band</button>
      <button className="big" onClick={save}>Save practice</button><div className="ok">{msg}</div>
      {can && <button className="d" onClick={del}>Delete practice</button>}
    </div>
  );
}

const ACC = ['#156082', '#0B7FAF', '#2F8A1F', '#7A3E9D', '#C2571A', '#C2185B'], SEC = ['#4EA72E', '#0F9ED5', '#E97132', '#7A3E9D', '#C2185B', '#B8860B'];

function Personalise() {
  const d = useData()!;
  const row = (cur: string, list: string[], key: 'accent' | 'accent2') => (
    <div className="sw">{list.map(c => <button key={c} style={{ background: c }} className={cur.toLowerCase() === c.toLowerCase() ? 'on' : ''} onClick={() => d.saveSettings({ [key]: c })} />)}
      <input type="color" value={cur} onChange={e => d.saveSettings({ [key]: e.target.value })} /></div>);
  return (
    <details className="card"><summary>Personalisation</summary>
      <label>Appearance</label>
      <div className="seg">{[['light', '☀ Light'], ['dark', '☾ Dark'], ['auto', 'Auto']].map(([k, l]) => <button key={k} className={d.theme === k ? 'on' : ''} onClick={() => d.saveSettings({ theme: k })}>{l}</button>)}</div>
      <label>Primary colour: buttons, tabs and selected items</label>{row(d.accent, ACC, 'accent')}
      <label>Secondary colour: money figures and income highlights</label>{row(d.accent2, SEC, 'accent2')}
      <button className="g" style={{ marginTop: 14 }} onClick={() => d.saveSettings({ accent: ACC[0], accent2: SEC[0] })}>Reset colours</button>
    </details>
  );
}

export default function Settings() {
  const d = useData(), r = useRouter();
  if (!d) return <p className="m">Loading…</p>;
  async function addPractice() { const b = d!.practices[0]; await sb.from('practices').insert({ name: 'New practice', uda_rate: b?.uda ?? 12, lab_share: b?.lab ?? 50, tiers: b?.tiers }); await d!.reload(); }
  return (
    <>
      <Personalise />
      {d.practices.map(p => <PracticeForm key={p.id + JSON.stringify(p.tiers) + p.uda} p={p} reload={d.reload} can={d.practices.length > 1} />)}
      <button className="g big" onClick={addPractice}>+ Add practice</button>
      <button className="d big" onClick={async () => { await sb.auth.signOut(); r.replace('/login'); }}>Sign out</button>
    </>
  );
}
