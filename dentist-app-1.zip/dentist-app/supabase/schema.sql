-- Run in Supabase: SQL Editor > New query > paste > Run.
create table public.settings(
  user_id uuid primary key references auth.users on delete cascade default auth.uid(),
  pay_day int not null default 15, tax_pct numeric(5,2) not null default 35,
  cutoffs text[] not null default array['2024-08-20','2024-09-17','2024-10-22','2024-11-19','2024-12-17','2025-01-21','2025-02-18','2025-03-28','2025-04-22','2025-05-20','2025-06-17','2025-07-22','2025-08-19','2025-09-23','2025-10-21','2025-11-18','2025-12-16','2026-01-20','2026-02-17','2026-03-17','2026-04-20','2026-05-18','2026-06-15','2026-07-20','2026-08-17','2026-09-21','2026-10-19'], quarter_mode text not null default 'std',
  theme text not null default 'light', accent text not null default '#156082', accent2 text not null default '#4EA72E');
create table public.practices(
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references auth.users on delete cascade default auth.uid(),
  name text not null, uda_rate numeric(10,2) not null default 12, lab_share numeric(5,2) not null default 50,
  tiers jsonb not null default '[{"up":11499.99,"r":40},{"up":22999.99,"r":45},{"up":null,"r":50}]',
  created_at timestamptz not null default now());
create table public.treatments(
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references auth.users on delete cascade default auth.uid(),
  name text not null, udas numeric(6,2) not null default 0, sort int not null default 0);
create table public.entries(
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references auth.users on delete cascade default auth.uid(),
  practice_id uuid references public.practices on delete set null,
  entry_date date not null, treatment text not null, initials text, note text,
  private_charge numeric(10,2) not null default 0, lab_fee numeric(10,2) not null default 0,
  submitted boolean not null default true, created_at timestamptz not null default now(), updated_at timestamptz not null default now());
create index on public.entries(user_id, entry_date);
create table public.referrals(
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references auth.users on delete cascade default auth.uid(),
  ref_date date not null, patient_ref text, referred_to text, reason text, sent_via text,
  sent boolean not null default false, made boolean not null default false, created_at timestamptz not null default now());
create table public.actual_pay(
  user_id uuid not null references auth.users on delete cascade default auth.uid(),
  month text not null, amount numeric(10,2) not null, primary key(user_id, month));
create table public.acct_records(
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references auth.users on delete cascade default auth.uid(),
  rec_date date not null, kind text not null check (kind in ('income','expense')),
  category text not null, who text, amount numeric(10,2) not null,
  ai_read boolean not null default false, created_at timestamptz not null default now());
create index on public.acct_records(user_id, rec_date);

create function public.touch_updated_at() returns trigger language plpgsql as $$ begin new.updated_at = now(); return new; end $$;
create trigger entries_touch before update on public.entries for each row execute function public.touch_updated_at();

-- Row Level Security: every user can only ever see and change their own rows.
do $$ declare t text; begin
  foreach t in array array['settings','practices','treatments','entries','referrals','actual_pay','acct_records'] loop
    execute format('alter table public.%I enable row level security', t);
    execute format('create policy "own rows" on public.%I for all using (user_id = auth.uid()) with check (user_id = auth.uid())', t);
  end loop; end $$;

-- New sign-up: create default settings, one practice and the starter treatment list.
create function public.handle_new_user() returns trigger language plpgsql security definer set search_path = public as $$
begin
  insert into settings(user_id) values (new.id);
  insert into practices(user_id, name) values (new.id, 'My practice');
  insert into treatments(user_id, name, udas, sort)
  select new.id, n, u, o from unnest(
    array['Exam','Emergency','Filling','3 Fillings','Perio','Extraction','Extraction x3','Incisor RCT','Pre-molar RCT','Molar RCT','Denture','Crown','Onlay','Night guard','Private'],
    array[1,1.2,3,5,3,3,5,3,5,7,12,12,12,12,0],
    array[1,2,3,4,5,6,7,8,9,10,11,12,13,14,15]) as x(n,u,o);
  return new;
end $$;
create trigger on_auth_user_created after insert on auth.users for each row execute function public.handle_new_user();
